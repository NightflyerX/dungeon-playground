const version = "1.4.4";

export default version;
