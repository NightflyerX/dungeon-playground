// tslint:disable-next-line: interface-name
interface JQuery {
    tree: any;
}
