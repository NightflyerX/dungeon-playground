---
title: getPreviousSibling
name: node-functions-getprevioussibling
---

Get the previous sibling of this node. Returns a node or null.

{% highlight js %}
var node = node.getPreviousSibling();
{% endhighlight %}
