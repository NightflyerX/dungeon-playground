-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql22j16.db.hostpoint.internal
-- Generation Time: Sep 27, 2019 at 12:47 PM
-- Server version: 10.1.41-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weixelba_dungeon3`
--

-- --------------------------------------------------------

--
-- Table structure for table `campaign`
--

CREATE TABLE `campaign` (
  `camp_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `master` int(3) NOT NULL,
  `date` date NOT NULL,
  `descr` text COLLATE utf8_unicode_ci NOT NULL,
  `public` tinyint(1) NOT NULL,
  `status` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chars`
--

CREATE TABLE `chars` (
  `char_id` int(11) NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chars`
--

INSERT INTO `chars` (`char_id`, `data`) VALUES
(1, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(10) NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` int(11) NOT NULL,
  `fields` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`id`, `fields`) VALUES
(1, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `game_id` int(11) NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci NOT NULL,
  `active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lib_data`
--

CREATE TABLE `lib_data` (
  `data_id` int(11) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lib_data`
--

INSERT INTO `lib_data` (`data_id`, `data`) VALUES
(1, '{\n    \"type_names\": [\n        {\n            \"name\": \"Sorcerer\"\n        },\n        {\n            \"name\": \"Necromancer\"\n        },\n        {\n            \"name\": \"Warrior\"\n        }\n    ],\n    \"races_names\": [\n        {\n            \"name\": \"Human\"\n        },\n        {\n            \"name\": \"Humanoid\"\n        },\n        {\n            \"name\": \"Undead\"\n        },\n        {\n            \"name\": \"Elf\"\n        },\n        {\n            \"name\": \"Dwarf\"\n        }\n    ],\n    \"attributes\": [\n        {\n            \"name\": \"strength\"\n        },\n        {\n            \"name\": \"accuracy\"\n        },\n        {\n            \"name\": \"stamina\"\n        },\n        {\n            \"name\": \"agility\"\n        },\n        {\n            \"name\": \"intellect\"\n        },\n        {\n            \"name\": \"charisma\"\n        },\n        {\n            \"name\": \"wisdom\"\n        },\n        {\n            \"name\": \"luck\"\n        }\n    ],\n    \"action_types\": [\n        {\n            \"key\": \"CLASS\",\n            \"name\": \"Class ability\"\n        },\n        {\n            \"key\": \"PHYSICAL\",\n            \"name\": \"Physical action\"\n        },\n        {\n            \"key\": \"MAGICAL\",\n            \"name\": \"Magical action\"\n        },\n        {\n            \"key\": \"ITEM\",\n            \"name\": \"Potion_Item\"\n        },\n        {\n            \"key\": \"OTHER\",\n            \"name\": \"Other_action\"\n        },\n        {\n            \"key\": \"DICEROLL\",\n            \"name\": \"Diceroll\"\n        }\n    ],\n    \"damage_types\": [\n        {\n            \"name\": \"Shot\",\n            \"color\": \"#ff80ff\"\n        },\n        {\n            \"name\": \"Blow\",\n            \"color\": \"#ff00ff\"\n        },\n        {\n            \"name\": \"Sting\",\n            \"color\": \"#ff0080\"\n        },\n        {\n            \"name\": \"Cut\",\n            \"color\": \"#ff80c0\"\n        },\n        {\n            \"name\": \"Poison\",\n            \"color\": \"#00ff00\"\n        },\n        {\n            \"name\": \"Fire\",\n            \"color\": \"#ff0000\"\n        }\n    ],\n    \"weapon_types\": [\n        {\n            \"name\": \"No_weapon\"\n        },\n        {\n            \"name\": \"Dagger_Knife\"\n        },\n        {\n            \"name\": \"Sword\"\n        },\n        {\n            \"name\": \"Hammer_Mace\"\n        },\n        {\n            \"name\": \"Whip\"\n        }\n    ],\n    \"pools\": [\n        {\n            \"id\": \"life\",\n            \"name\": \"Life points\"\n        },\n        {\n            \"id\": \"mana\",\n            \"name\": \"Mana points\"\n        },\n        {\n            \"id\": \"ap\",\n            \"name\": \"Action points\"\n        },\n        {\n            \"id\": \"move\",\n            \"name\": \"Movement\"\n        },\n        {\n            \"id\": \"poison\",\n            \"name\": \"Poison\"\n        },\n        {\n            \"id\": \"sickness\",\n            \"name\": \"Sickness\"\n        },\n        {\n            \"id\": \"lp_shield\",\n            \"name\": \"LP_Shield\"\n        }\n    ],\n    \"mods\": [\n        {\n            \"attribute_value\": 0,\n            \"mod_value\": -6\n        },\n        {\n            \"attribute_value\": 3,\n            \"mod_value\": -5\n        },\n        {\n            \"attribute_value\": 5,\n            \"mod_value\": -4\n        },\n        {\n            \"attribute_value\": 7,\n            \"mod_value\": -3\n        },\n        {\n            \"attribute_value\": 9,\n            \"mod_value\": -2\n        },\n        {\n            \"attribute_value\": 11,\n            \"mod_value\": -1\n        },\n        {\n            \"attribute_value\": 13,\n            \"mod_value\": 0\n        },\n        {\n            \"attribute_value\": 15,\n            \"mod_value\": 1\n        },\n        {\n            \"attribute_value\": 17,\n            \"mod_value\": 2\n        },\n        {\n            \"attribute_value\": 19,\n            \"mod_value\": 3\n        },\n        {\n            \"attribute_value\": 21,\n            \"mod_value\": 4\n        },\n        {\n            \"attribute_value\": 25,\n            \"mod_value\": 5\n        },\n        {\n            \"attribute_value\": 30,\n            \"mod_value\": 6\n        },\n        {\n            \"attribute_value\": 35,\n            \"mod_value\": 7\n        },\n        {\n            \"attribute_value\": 40,\n            \"mod_value\": 8\n        },\n        {\n            \"attribute_value\": 50,\n            \"mod_value\": 9\n        },\n        {\n            \"attribute_value\": 75,\n            \"mod_value\": 10\n        },\n        {\n            \"attribute_value\": 100,\n            \"mod_value\": 11\n        },\n        {\n            \"attribute_value\": 125,\n            \"mod_value\": 12\n        },\n        {\n            \"attribute_value\": 150,\n            \"mod_value\": 13\n        },\n        {\n            \"attribute_value\": 175,\n            \"mod_value\": 14\n        },\n        {\n            \"attribute_value\": 200,\n            \"mod_value\": 15\n        },\n        {\n            \"attribute_value\": 225,\n            \"mod_value\": 16\n        },\n        {\n            \"attribute_value\": 250,\n            \"mod_value\": 17\n        },\n        {\n            \"attribute_value\": 275,\n            \"mod_value\": 18\n        },\n        {\n            \"attribute_value\": 300,\n            \"mod_value\": 19\n        },\n        {\n            \"attribute_value\": 350,\n            \"mod_value\": 20\n        },\n        {\n            \"attribute_value\": 400,\n            \"mod_value\": 25\n        },\n        {\n            \"attribute_value\": 500,\n            \"mod_value\": 25\n        }\n    ],\n    \"defensive\": [\n        {\n            \"name\": \"Dodge\"\n        },\n        {\n            \"name\": \"Robe\"\n        },\n        {\n            \"name\": \"Leather_armor\"\n        },\n        {\n            \"name\": \"Chain_armor\"\n        },\n        {\n            \"name\": \"Plate_armor\"\n        },\n        {\n            \"name\": \"Shield\"\n        },\n        {\n            \"name\": \"Cape\"\n        }\n    ],\n    \"magic_classes\": [\n        {\n            \"name\": \"Arcane_magic\",\n            \"color\": \"#ff0000\"\n        },\n        {\n            \"name\": \"Spiritual_magic\",\n            \"color\": \"#0000a0\"\n        },\n        {\n            \"name\": \"Alchemy\",\n            \"color\": \"#008000\"\n        }\n    ],\n    \"magic_types\": [\n        {\n            \"magic_class_name\": \"Arcane_magic\",\n            \"magic_type_name\": \"Earth\",\n            \"color\": \"#ff8040\",\n            \"glyph\": \"si-glyph-mountain\"\n        },\n        {\n            \"magic_class_name\": \"Arcane_magic\",\n            \"magic_type_name\": \"Fire\",\n            \"color\": \"#ff0000\",\n            \"glyph\": \"si-glyph-fire\"\n        },\n        {\n            \"magic_class_name\": \"Arcane_magic\",\n            \"magic_type_name\": \"Water\",\n            \"color\": \"#0000ff\",\n            \"glyph\": \"si-glyph-drop-water\"\n        },\n        {\n            \"magic_class_name\": \"Arcane_magic\",\n            \"magic_type_name\": \"Air\",\n            \"color\": \"#80ffff\",\n            \"glyph\": \"si-glyph-wind-turbines\"\n        },\n        {\n            \"magic_class_name\": \"Spiritual_magic\",\n            \"magic_type_name\": \"Illutions\",\n            \"color\": \"#ff0080\",\n            \"glyph\": \"si-glyph-image\"\n        },\n        {\n            \"magic_class_name\": \"Spiritual_magic\",\n            \"magic_type_name\": \"Necromancy\",\n            \"color\": \"#00ff80\",\n            \"glyph\": \"si-glyph-skull\"\n        },\n        {\n            \"magic_class_name\": \"Alchemy\",\n            \"magic_type_name\": \"Material_change\",\n            \"color\": \"#8080c0\",\n            \"glyph\": \"si-glyph-connect-2\"\n        }\n    ],\n    \"skill_classes\": [\n        {\n            \"name\": \"Body_and_mind\"\n        },\n        {\n            \"name\": \"Skills\"\n        },\n        {\n            \"name\": \"Other\"\n        }\n    ],\n    \"skill_types\": [\n        {\n            \"skill_class_name\": \"Body_and_mind\",\n            \"skill_type_name\": \"Bodybuilding\"\n        },\n        {\n            \"skill_class_name\": \"Body_and_mind\",\n            \"skill_type_name\": \"Meditation\"\n        },\n        {\n            \"skill_class_name\": \"Body_and_mind\",\n            \"skill_type_name\": \"Regeneration\"\n        },\n        {\n            \"skill_class_name\": \"Skills\",\n            \"skill_type_name\": \"Craftmanship\"\n        },\n        {\n            \"skill_class_name\": \"Skills\",\n            \"skill_type_name\": \"Trade\"\n        },\n        {\n            \"skill_class_name\": \"Other\",\n            \"skill_type_name\": \"Sneak\"\n        }\n    ],\n    \"states\": [\n        {\n            \"state_name\": \"dsfg\",\n            \"state_id\": \"1568298387\",\n            \"vars\": [\n                {\n                    \"path\": \"char.level\",\n                    \"modifier\": \"+1\"\n                }\n            ]\n        },\n        {\n            \"state_name\": \"Test\",\n            \"state_id\": \"1568298552\",\n            \"vars\": [\n                {\n                    \"path\": \"char.level\",\n                    \"modifier\": \"+2\"\n                },\n                {\n                    \"path\": \"char.pools.life.max\",\n                    \"modifier\": \"+20\"\n                }\n            ]\n        },\n        {\n            \"state_name\": \"Tanked\",\n            \"state_id\": \"1569505181\",\n            \"vars\": [\n                {\n                    \"path\": \"\",\n                    \"modifier\": \"\"\n                }\n            ]\n        },\n        {\n            \"state_name\": \"Tanked\",\n            \"state_id\": 1569507420,\n            \"vars\": [\n                {\n                    \"path\": \"\",\n                    \"modifier\": \"\"\n                }\n            ]\n        }\n    ],\n    \"states_effects2\": [],\n    \"damage_types_all\": [\n        {\n            \"name\": \"Physical general\",\n            \"color\": \"#ffffff\"\n        },\n        {\n            \"name\": \"Physical Shot\",\n            \"color\": \"#ff80ff\"\n        },\n        {\n            \"name\": \"Physical Blow\",\n            \"color\": \"#ff00ff\"\n        },\n        {\n            \"name\": \"Physical Sting\",\n            \"color\": \"#ff0080\"\n        },\n        {\n            \"name\": \"Physical Cut\",\n            \"color\": \"#ff80c0\"\n        },\n        {\n            \"name\": \"Physical Poison\",\n            \"color\": \"#00ff00\"\n        },\n        {\n            \"name\": \"Physical Fire\",\n            \"color\": \"#ff0000\"\n        },\n        {\n            \"name\": \"Magic general\",\n            \"color\": \"#ccccff\"\n        },\n        {\n            \"name\": \"Magic Arcane_magic\",\n            \"color\": \"#ff0000\"\n        },\n        {\n            \"name\": \"Magic Spiritual_magic\",\n            \"color\": \"#0000a0\"\n        },\n        {\n            \"name\": \"Magic Alchemy\",\n            \"color\": \"#008000\"\n        },\n        {\n            \"name\": \"Magic Earth\",\n            \"color\": \"#ff8040\"\n        },\n        {\n            \"name\": \"Magic Fire\",\n            \"color\": \"#ff0000\"\n        },\n        {\n            \"name\": \"Magic Water\",\n            \"color\": \"#0000ff\"\n        },\n        {\n            \"name\": \"Magic Air\",\n            \"color\": \"#80ffff\"\n        },\n        {\n            \"name\": \"Magic Illutions\",\n            \"color\": \"#ff0080\"\n        },\n        {\n            \"name\": \"Magic Necromancy\",\n            \"color\": \"#00ff80\"\n        },\n        {\n            \"name\": \"Magic Material_change\",\n            \"color\": \"#8080c0\"\n        }\n    ],\n    \"special_token\": [\n        {\n            \"name\": \"Poison-Token\",\n            \"color\": \"#00ff00\"\n        },\n        {\n            \"name\": \"Bleeding-Token\",\n            \"color\": \"#ff0000\"\n        },\n        {\n            \"name\": \"Fire-Token\",\n            \"color\": \"#ff8000\"\n        }\n    ],\n    \"events\": [\n        {\n            \"event\": \"on_round_start\"\n        },\n        {\n            \"event\": \"on_attack\"\n        },\n        {\n            \"event\": \"on_mk_damage\"\n        },\n        {\n            \"event\": \"on_add_token\"\n        },\n        {\n            \"event\": \"on_add_special_token\"\n        },\n        {\n            \"event\": \"on_made_damage\"\n        }\n    ]\n}');

-- --------------------------------------------------------

--
-- Table structure for table `lib_equipment`
--

CREATE TABLE `lib_equipment` (
  `equipment_id` int(11) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lib_equipment`
--

INSERT INTO `lib_equipment` (`equipment_id`, `data`) VALUES
(1, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `lib_sorceries`
--

CREATE TABLE `lib_sorceries` (
  `sorcery_id` int(11) NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lib_sorceries`
--

INSERT INTO `lib_sorceries` (`sorcery_id`, `data`) VALUES
(1, '[\n  {\n    \"action_name\": \"Test\",\n    \"action_type\": \"Physical action\",\n    \"action_magic_type\": \"Earth\",\n    \"hit_chance_formula\": \"100%\",\n    \"attributes\": [],\n    \"description\": \"\",\n    \"uservars\": [],\n    \"tier_lvl\": [\n      {\n        \"tier_lvl_name\": \"Normal\",\n        \"target_area\": \"Single target\",\n        \"only_char_filter\": [],\n        \"min_level_filter\": \"Normal\",\n        \"weapon_filters\": [\n          {\n            \"weapon_filter\": \"Dagger_Knife\",\n            \"weapon_tier_level_filter\": \"tier 1\",\n            \"weapon_skill_filter\": \"Dagger_Knife\",\n            \"weapon_skill_level_filter\": \"Normal\"\n          },\n          {\n            \"weapon_filter\": \"Sword\",\n            \"weapon_tier_level_filter\": \"tier 3\",\n            \"weapon_skill_filter\": \"Sword\",\n            \"weapon_skill_level_filter\": \"Normal\"\n          }\n        ],\n        \"magic_filters\": [],\n        \"other_skill_filters\": [],\n        \"item_filters\": [],\n        \"damage\": [\n          {\n            \"damage_type\": \"Physical general\",\n            \"formula\": \"10\",\n            \"damage_heal\": \"damage\",\n            \"affected_damage_pool\": \"Life points\",\n            \"skip_resistance\": \"false\"\n          }\n        ],\n        \"effect_add_damage\": [],\n        \"effect_add_special_token\": [],\n        \"effect_add_state\": [],\n        \"effect_summon_char\": [],\n        \"effect_add_field\": [],\n        \"cost\": [],\n        \"token_cost\": [],\n        \"message_after_attack\": \"\"\n      }\n    ]\n  },\n  {\n    \"action_name\": \"Tank\",\n    \"action_type\": \"Other_action\",\n    \"action_magic_type\": \"Earth\",\n    \"hit_chance_formula\": \"100%\",\n    \"attributes\": [],\n    \"description\": \"\",\n    \"uservars\": [],\n    \"tier_lvl\": [\n      {\n        \"tier_lvl_name\": \"Normal\",\n        \"target_area\": \"Single target\",\n        \"only_char_filter\": [],\n        \"min_level_filter\": \"Normal\",\n        \"weapon_filters\": [],\n        \"magic_filters\": [],\n        \"other_skill_filters\": [],\n        \"item_filters\": [],\n        \"damage\": [],\n        \"effect_add_damage\": [],\n        \"effect_add_special_token\": [],\n        \"effect_add_state\": [\n          {\n            \"chance\": \"100%\",\n            \"state\": \"Tanked\",\n            \"target\": \"action_target\",\n            \"rounds\": \"99\",\n            \"add_remove\": \"add\"\n          }\n        ],\n        \"effect_summon_char\": [],\n        \"effect_add_field\": [],\n        \"cost\": [],\n        \"token_cost\": [],\n        \"message_after_attack\": \"\"\n      }\n    ]\n  }\n]');

-- --------------------------------------------------------

--
-- Table structure for table `lib_weapons`
--

CREATE TABLE `lib_weapons` (
  `weapon_id` int(11) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lib_weapons`
--

INSERT INTO `lib_weapons` (`weapon_id`, `data`) VALUES
(1, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `data_id` int(5) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`data_id`, `data`) VALUES
(1, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `timestamp`
--

CREATE TABLE `timestamp` (
  `id` int(5) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `timestamp`
--

INSERT INTO `timestamp` (`id`, `timestamp`) VALUES
(1, '2019-09-26 11:32:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `campaign`
--
ALTER TABLE `campaign`
  ADD PRIMARY KEY (`camp_id`);

--
-- Indexes for table `chars`
--
ALTER TABLE `chars`
  ADD PRIMARY KEY (`char_id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `lib_data`
--
ALTER TABLE `lib_data`
  ADD PRIMARY KEY (`data_id`);

--
-- Indexes for table `lib_equipment`
--
ALTER TABLE `lib_equipment`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `lib_sorceries`
--
ALTER TABLE `lib_sorceries`
  ADD PRIMARY KEY (`sorcery_id`);

--
-- Indexes for table `lib_weapons`
--
ALTER TABLE `lib_weapons`
  ADD PRIMARY KEY (`weapon_id`);

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`data_id`);

--
-- Indexes for table `timestamp`
--
ALTER TABLE `timestamp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `campaign`
--
ALTER TABLE `campaign`
  MODIFY `camp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chars`
--
ALTER TABLE `chars`
  MODIFY `char_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `game`
--
ALTER TABLE `game`
  MODIFY `game_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lib_data`
--
ALTER TABLE `lib_data`
  MODIFY `data_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lib_equipment`
--
ALTER TABLE `lib_equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lib_sorceries`
--
ALTER TABLE `lib_sorceries`
  MODIFY `sorcery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lib_weapons`
--
ALTER TABLE `lib_weapons`
  MODIFY `weapon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shops`
--
ALTER TABLE `shops`
  MODIFY `data_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `timestamp`
--
ALTER TABLE `timestamp`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
