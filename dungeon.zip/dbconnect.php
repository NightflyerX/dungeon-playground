<?php

if( !isset( $db ) ){

	define( "__DBNAME__", "dbname" );
	define( "__DBUSER__", "dbuser" );
	define( "__DBPASS__", "dbpass" );
	define( "SALT", "3#��%&" );

	$db = new PDO('mysql:host=weixelba.mysql.db.internal;dbname='.__DBNAME__.';charset=utf8mb4', __DBUSER__, __DBPASS__ );
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}